package connection;

public class WeatherMain {

	public static void main(String[] args) {
		weather w = new weather();
		JSP j = new JSP();
		
		
	}

}

/**
	Date : 2020-06-16
	Author : 김태석, 오은희, 윤희영, 임형민
	Description : 
	Version : 1.0
*/
package action;

import java.util.Scanner;

public interface Action {

	void excute(Scanner sc) throws Exception;
}
